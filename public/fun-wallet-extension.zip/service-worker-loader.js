import './assets/service-worker.ts-DViYGVVg.js';
