import './assets/service-worker.ts-72F0EZst.js';
